<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm-password'];

    // Basic validation
    if ($password !== $confirm_password) {
        echo "Passwords do not match!";
    } else {
        // Save the data (you can store it in a database or a file)
        // Example: save to a text file (for demonstration purposes)
        $data = "Name: $name\nEmail: $email\nPassword: $password\n";
        file_put_contents("users.txt", $data, FILE_APPEND);
        echo "Sign up successful!";
    }
}
?>
